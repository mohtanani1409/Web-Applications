
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed
 */
public class cart implements Serializable  {
    
   public ArrayList <orderItem>items;
   ArrayList<orderItem> getitems=new ArrayList();
   
   List <Integer> codes=new ArrayList();
   
   orderItem oi=new orderItem();
   
   public cart()
   {
        codes = new ArrayList();
       
       items=new ArrayList<orderItem>();
   }
   
    public ArrayList<orderItem> getItems() {
        return  items;
    }
   
     public int getCount() {
        return items.size();
    }
   
   public void additem(orderItem item)
   {
     
     int code = item.getProduct().getCode();
        int quantity = item.getQuantity();
        for (int i = 0; i < items.size(); i++) {
            orderItem lineItem = items.get(i);
            if (lineItem.getProduct().getCode()==code) {
                if (lineItem.getQuantity()>0)
                {
                    lineItem.setQuantity(quantity+lineItem.getQuantity());
                    // lineItem.setQuantity(quantity);
                    return;
                }
                else
                {
                    lineItem.setQuantity(quantity);
                return;
                }
                
            }
            
        }
        
        
        items.add(item);  
       
       
   }
   
    public void updateitem(orderItem item)
   {
     
     int code = item.getProduct().getCode();
        int quantity = item.getQuantity();
        for (int i = 0; i < items.size(); i++) {
            orderItem lineItem = items.get(i);
            if (lineItem.getProduct().getCode()==code) {
         
                    lineItem.setQuantity(quantity);
                return;
                
                
            }
            
        }
        
        
        items.add(item);  
       
       
   }
    
   
   public void removeItem(orderItem item)
   {
        int code = item.getProduct().getCode();
        
        for (int i = 0; i < items.size(); i++) {
            orderItem lineItem = items.get(i);
            if (lineItem.getProduct().getCode()==code) {
                items.remove(i);
                return;
            }
        }
       
   }
   
   public ArrayList getItemsAll()
   {
       return items;
   }
   
   public void emptyCart()
   {
       items=null;
   }
    
}
