/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mohamed
 */
public class orderController extends HttpServlet {
    public  List <Integer> onlyCodes=new ArrayList();
@Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
         ServletContext sc = getServletContext();

         productDB db;
         
          String action=request.getParameter("action");
          
          if (action == null) {
            action = "cart";  // default action
        }
                 
          String url="/mainPage.jsp";
          
        
        int code2=0;
       int initialTotal=0;
       double tax=0;
       double finalTotal=0;
        double total=0;
        int userID;
     
               HttpSession session = request.getSession();
          cart cart=(cart) session.getAttribute("cart");
 
          orderItem oi=new orderItem();
          
          List <orderItem> list=new ArrayList <> ();
          
          List <String> stringList=new ArrayList <> ();

         if (action.equals("cart"))
        {
            
            String code=request.getParameter("productCode");
            String quantityString = request.getParameter("quantity");
            
            code2=Integer.parseInt(code);
            
            db=new productDB();
            
        if(cart==null)
        {
            cart=new cart();
        }
   
         //if the user enters a negative or invalid quantity,
            //the quantity is automatically reset to 1.
            int quantity;
            try {
                quantity = Integer.parseInt(quantityString);
                if (quantity < 0) {
                    quantity = 1;
                }
            } catch (NumberFormatException nfe) {
                quantity = 1;
            }

        oi.setProduct(productDB.selectproduct(code));
        
       
        oi.setQuantity(quantity);    
        
        oi.setCode(code2);
        
 
       oi.setFinalTotl(productDB.selectPrice(code));
       boolean flag=false;
        
        if (quantity>0)
        {
        cart.additem(oi);   
        cart.codes.add(code2);
        
        
        }
        
        else if (quantity==0)
        {
            cart.removeItem(oi);
            cart.codes.remove(code2);
            
             
        }
        
        
        for (int x=0;x<cart.items.size();x++)
             {
             initialTotal+= (int) cart.items.get(x).getFinaltotal();    
             }
             
             tax=initialTotal*0.09;
             finalTotal=initialTotal+tax;
                                       
        NumberFormat currency = NumberFormat.getCurrencyInstance();
         currency.format(tax);
    
             
              session.setAttribute("total", initialTotal);
             
             session.setAttribute("tax",currency.format(tax) );
             session.setAttribute("finalTotal", finalTotal);
        
       
        session.setAttribute("cart", cart);
  
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/shoppingCart.jsp";
            
            
        }
         
         //edit quantity
         else if (action.equals("1"))
         {
            String code=request.getParameter("action12");
            String quantityString = request.getParameter("quantity");
            
            code2=Integer.parseInt(code);
            
            db=new productDB();
            
            int ww=Integer.parseInt(code);
            
            onlyCodes.add(ww);
            
            orderItem orIt=new orderItem();
            
             stringList.add("1");
          stringList.add("2");
            
            
        if(cart==null)
        {
            cart=new cart();
        }
   
         //if the user enters a negative or invalid quantity,
            //the quantity is automatically reset to 1.
            int quantity;
            try {
                quantity = Integer.parseInt(quantityString);
                if (quantity < 0) {
                    quantity = 1;
                }
            } catch (NumberFormatException nfe) {
                quantity = 1;
            }
            
  
        oi.setProduct(productDB.selectproduct(code));
        
        orIt.setProduct(productDB.selectproduct(code));
        
       
        oi.setQuantity(quantity);    
        
        orIt.setQuantity(quantity);
        
        oi.setCode(code2);
        
        orIt.setCode(code2);
  
       oi.setFinalTotl(productDB.selectPrice(code));
       
       list.add(orIt);
       
       
       boolean flag=false;
        
        if (quantity>0)
        {
        cart.updateitem(oi);   
        cart.codes.add(code2);
        
        }
        
        else if (quantity==0)
        {
            cart.removeItem(oi);
            cart.codes.remove(code2);
                                      
        }
        
        
        for (int x=0;x<cart.items.size();x++)
             {
             initialTotal+= (int) cart.items.get(x).getFinaltotal();    
             }
             
             tax=initialTotal*0.09;
             finalTotal=initialTotal+tax;
             
             NumberFormat currency = NumberFormat.getCurrencyInstance();
         
             
              session.setAttribute("total", initialTotal);
             session.setAttribute("tax", currency.format(tax));
             session.setAttribute("finalTotal", finalTotal);
        
       
        session.setAttribute("cart", cart);
        
        
             db.addOrderItem(cart);
        
        
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/shoppingCart.jsp";
            
            
            
         }
         
         //delete item from cart
         else if (action.equals("deleteItem"))
         {
             
             
             String code=request.getParameter("action2");
            
            
        if(cart==null)
        {
            cart=new cart();
        }
   
         //if the user enters a negative or invalid quantity,
            //the quantity is automatically reset to 1.
            int quantity=0;
     
        oi.setProduct(productDB.selectproduct(code));
        
       
        oi.setQuantity(quantity);    
        
        oi.setCode(code2);
        //oi.setFinalTotl(db.list.get(code2).getPrice());
       oi.setFinalTotl(productDB.selectPrice(code));
       
      
            cart.removeItem(oi);
            cart.codes.remove(code2);
            
             
        for (int x=0;x<cart.items.size();x++)
             {
             initialTotal+= (int) cart.items.get(x).getFinaltotal();    
             }
             
             tax=initialTotal*0.09;
             finalTotal=initialTotal+tax;
             
             NumberFormat currency = NumberFormat.getCurrencyInstance();
             
              session.setAttribute("total", initialTotal);
             session.setAttribute("tax", currency.format(tax));
             session.setAttribute("finalTotal", finalTotal);
        
       
        session.setAttribute("cart", cart);
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/shoppingCart.jsp";
             
    
         }
         
      
         //checkout page
         else if(action.equals("checkout"))
              
         {
             if (session.getAttribute("userID")==null)
             {
                 request.setAttribute("name", "Not Signed In");
                 request.setAttribute("error", "You are not signed in! Please Sign in so you can checkout your order. ");
                 
                          if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                 url="/shoppingCart.jsp";
             }
             else
             {
                 
             
             
             DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
            System.out.println(dateFormat.format(date)); //2016/11/16 12:08:43
             
             for (int x=0;x<cart.items.size();x++)
             {
             initialTotal+= (int) cart.items.get(x).getFinaltotal();    
             }
             
             tax=initialTotal*0.09;
             finalTotal=initialTotal+tax;
             
             NumberFormat currency = NumberFormat.getCurrencyInstance();
             session.setAttribute("total", initialTotal);
             session.setAttribute("tax", currency.format(tax));
             session.setAttribute("finalTotal", finalTotal);
             session.setAttribute("date", date);
             
             session.setAttribute("cart",cart);
             request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
             request.setAttribute("name2"," "+ session.getAttribute("userName"));
             
                      if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                       request.setAttribute("address", session.getAttribute("address"));
                  }
             url="/order.jsp";
             }
         }
         
         
         
         else if (action.equals("backToCart")||action.equals("myCart"))
         {
              session.setAttribute("cart",cart);
                         if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
             url="/shoppingCart.jsp";
         }
         
         else if (action.equals("viewOrders"))
         {
          
             if (session.getAttribute("userID")==null)
             {
                   ArrayList <products> product=productDB.selectProducts();
           
        request.setAttribute("products", product);
             if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
                 url="/catalog.jsp";
                 //url="/mainPage1.jsp";
             }
             
             else 
             {
                 
             
              db=new productDB();
              
              //getting the user id fro session
              String id=session.getAttribute("userID").toString();
               userID= Integer.parseInt(id);
              
              
              ArrayList <order> list22=new ArrayList();
              
              list22=productDB.selectOrders(userID);
   
              session.setAttribute("list22", list22);
              
              
                         if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
             url="/orderList.jsp";
             //url="/mainPage1.jsp";
             }
         }
         
         
         
         else if (action.equals("purchase"))
         {
             session.setAttribute("total", finalTotal);
                         if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
             url="/payment.jsp";
         }
         
               else if (action.equals("admin"))
         {
             //request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
             
                      if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
             url="/admin.jsp";
         }
         
               else if (action.equals("confirmPayment"))
               {
                   
                   db=new productDB();
                   db.addOrderItem(cart);
                   
                   
                   db.addOrder(cart,session.getAttribute("userID").toString());
                   
                   
                    
                    
                   
                               if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                               
                   session.setAttribute("cart", null);
                   request.setAttribute("message", "Your payment has been processed successfully.");
                   request.setAttribute("message2", "Thank you for shopping with us.");
                   
                   url="/finalMessage.jsp";
                   
               }
         
               else if (action.equals("displayAllorders"))
               {
                   
                      session.setAttribute("cart",cart);
              
              
              
              db=new productDB();
              
              ArrayList <order> list22=new ArrayList();
              
              list22=productDB.selectAllOrders();
   
              session.setAttribute("list22", list22);
              
              
                          if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
                   url="/orderList.jsp";
               }
         
               else if (action.equals("signIn"))
               {
                    if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                   url="/signIn.jsp";
               }
         
               //sign in 
                 else if (action.equals("signIn2"))
               {
                   List <user> users=new ArrayList <> ();
                   users=productDB.selectUsers();
                   String username=request.getParameter("userName");
                   String password=request.getParameter("password");
                   String hashedPassword="";
                   
                   //hash password
                          try {
                             
                                 hashedPassword=PasswordUtil.hashPassword(password);
                                 
                            } catch (NoSuchAlgorithmException ex) {
                                Logger.getLogger(orderController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                   
 
                   //if there are no users in database 
                   if (users==null)
                   {
                        request.setAttribute("error", "The username or password is wrong! Try Again Please");
                        
                                            if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                           url="/signIn.jsp";
                       
                   }
                   else
                   {                      
                   
                   
                   for (int x=0;x<users.size();x++)
                   {
                       if (users.get(x).id.equals(username)&&users.get(x).password.equals(hashedPassword))
                       {
                           
                           
                           session.setAttribute("userID", users.get(x).id2);
                           
                           session.setAttribute("userName", users.get(x).firstName);
                           session.setAttribute("fName", users.get(x).firstName);
                           session.setAttribute("lName", users.get(x).lastName);
                           session.setAttribute("email", users.get(x).emailAddress);
                           session.setAttribute("password", users.get(x).password);
                           session.setAttribute("address", users.get(x).addressField1);
                           session.setAttribute("role", users.get(x).role);
                           session.setAttribute("userName2", users.get(x).id);
                           
                           
                           //request.setAttribute("name","Signed In: "+ users.get(x).firstName);
                           request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                           
                           if (users.get(x).role==1)
                           {
                                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                           url="/admin.jsp";
                           }
                           else
                           {
                                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                               
                               url="/mainPage.jsp";
                           }
                           
                           break;
                       }
                       else
                       {
                           request.setAttribute("error", "The username or password is wrong! Try Again Please");
                           
                                               if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                           url="/signIn.jsp";
                           
                           
                       }
                   }
               }
                   
                  
               }
         
              else if (action.equals("signUp"))
               {
                    if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                   url="/signUp.jsp";
               }
              
              //sign up
              else if (action.equals("signUp2"))
               {
                   
                    String fname=request.getParameter("fName");
                    String lname=request.getParameter("lName");
                    String uname=request.getParameter("userName");
                    String password=request.getParameter("password");
                    String confirmPassword=request.getParameter("confirmPassword");
                    String email=request.getParameter("email");
                    String address=request.getParameter("address");
                    String phoneNumber=request.getParameter("phoneNumber");
                    String role=request.getParameter("role");
                    
                     String hashedPassword="";
                   
                    
                    
                    if (password.equals(confirmPassword))
                    {
                        
                        if (role==null)
                        {
                            request.setAttribute("error", "Role is not selected! Select a role please");
                            
                                                if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                            url="/signUp.jsp";
                        }
                        
                        else
                        {
                            
                               try {
                             
                                 hashedPassword=PasswordUtil.hashPassword(password);
                                 
                            } catch (NoSuchAlgorithmException ex) {
                                Logger.getLogger(orderController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            
                        
                     
                   productDB.addUser(fname,lname,uname,hashedPassword,email,address,phoneNumber,role);
                   
                                 if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                   
                   request.setAttribute("message", "Your account has been created successfully!");
                   request.setAttribute("message2", "Sign In and Enjoy your shopping, Thank you!");
            
                   url="/finalMessage.jsp";
                    }
               
               }
                    
                    else
                    {
                         request.setAttribute("error", "Password and confirm password don't match! Try again please");
                         
                                             if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                        url="/signUp.jsp";
                        
                    }
                    
               }
         
              else if(action.equals("signOut"))
              {
                  session.setAttribute("cart", null);
                  session.setAttribute("userName", null);
                  session.setAttribute("userID", null);
                  session.setAttribute("role", null);
                  session.setAttribute("userName2", null);
                  session.setAttribute("role", null);
                  session.setAttribute("fName", null);
                  session.setAttribute("lName", null);
                  session.setAttribute("email", null);
                  session.setAttribute("password", null);
                  session.setAttribute("address", null);
                  
                  
                  
                   
              request.setAttribute("name","Not Signed In ");    
              
                                                 if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                  url="/mainPage.jsp";
              }
         
              //reset password page
                 else if(action.equals("goToResetPasswordPage"))
              {
                                      if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                  
                  url="/findUserName.jsp";
              }
                 
                else if(action.equals("goFindUserName2"))
              {
                  List <user> users=new ArrayList <> ();
                   users=productDB.selectUsers();
                   String userName=request.getParameter("userName");
                   
                   boolean flag=false;
                   
                   for (int x=0;x<users.size();x++)
                   {
                    if (users.get(x).id.equals(userName))
                       
                            {
                                String id=users.get(x).id2;
                                                                
                                session.setAttribute("resetPasswordId", cart);
                                session.setAttribute("idFound", users.get(x).id2);
                                
                                
                                         if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                  url="/resetPassword.jsp";    
                  flag=true;
                  break;
                            }               
                    
                    
                   }
                   
                   if (flag==false)
                   {
                        request.setAttribute("error", "Invalid username, try again please!");
                                            if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                        url="/findUserName.jsp";
                   }
                  
                  
              }
         
                     else if(action.equals("resetPassword1"))
              {
                  String password=request.getParameter("password");
                  String confirmPassword=request.getParameter("confirmPassword");
                  
                  String id=request.getParameter("id22");
                  
                  //reset password
                  if (password.equals(confirmPassword))
                  {
                      
                    String hashedPassword="";
                   
                   //hash password
                          try {
                             
                                 hashedPassword=PasswordUtil.hashPassword(password);
                                 
                            } catch (NoSuchAlgorithmException ex) {
                                Logger.getLogger(orderController.class.getName()).log(Level.SEVERE, null, ex);
                            }  
                     
                      
                      String now= session.getAttribute("idFound").toString();
                      
                      request.setAttribute("id",now );
                      int id2=Integer.parseInt(now);
                      
                      //userDB.resetPassword();
                      
                      int wow=userDB.resetPassword(id2,hashedPassword);
                      
                      request.setAttribute("result", wow);
                      
                               if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                      request.setAttribute("message", "Your password has been reset. You can log in now!");
                      url="/finalMessage.jsp";
                      
                  }
                  else
                  
                  {
                      
                      request.setAttribute("error", "Password and confirm password don't match! Try again please.");
                      
                                          if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                  url="/resetPassword.jsp";    
                  }
                                    
              }
                     //edit profile page
                     else if (action.equals("editProfile"))
                     {
                         if (session.getAttribute("userName")==null)
                         {
                             request.setAttribute("error2", "You must be signed in first so you can edit your profile!");
                             
                                      if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                             url="/mainPage.jsp";
                         }
                         
                         else
                         {
                             
                             request.setAttribute("fName", session.getAttribute("fName"));
                             request.setAttribute("lName", session.getAttribute("lName"));
                             request.setAttribute("userName2", session.getAttribute("userName2"));
                             request.setAttribute("password", session.getAttribute("password"));
                             request.setAttribute("email", session.getAttribute("email"));
                             request.setAttribute("address", session.getAttribute("address"));
                             request.setAttribute("phoneNumber", session.getAttribute("phoneNumber"));
                             request.setAttribute("role", session.getAttribute("role"));
                             
                                                 if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                             
                             url="/editProfile.jsp";
                         }
                     }
         
                    //submit edditing
                     else if (action.equals("edit"))
                     {
                    
                    String now= session.getAttribute("userID").toString();
                  
                    int id2=Integer.parseInt(now);
                    String fname=request.getParameter("fName");
                    String lname=request.getParameter("lName");
                    String uname=request.getParameter("userName");
                    String password=request.getParameter("password");
                    String confirmPassword=request.getParameter("confirmPassword");
                    String email=request.getParameter("email");
                    String address=request.getParameter("address");
                    String phoneNumber=request.getParameter("phoneNumber");
                    String role=request.getParameter("role");
                    
                    if (!password.equals(confirmPassword))
                    {
                        request.setAttribute("error", "Password and confirm password don't match! Try again please.");
                        
                                 if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                        url="/editProfile.jsp";
                        
                    }
                    
                    else if (role==null)
                    {
                        request.setAttribute("error", "Role is not selected! Select a role please");
                        
                                 if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                        url="/editProfile.jsp";
                    }
                    
                    else
                    {
                         String hashedPassword="";
                   
                   //hash password
                          try {
                             
                                 hashedPassword=PasswordUtil.hashPassword(password);
                                 
                            } catch (NoSuchAlgorithmException ex) {
                                Logger.getLogger(orderController.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        
                        
                        
                        
                        userDB.editProfile(id2, fname, lname, uname, hashedPassword, address, phoneNumber, email, role);
                        
                                            if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                        
                        request.setAttribute("message", "Your profile has been updated successfully!");
                        request.setAttribute("message2", "Thank You");
                        url="/finalMessage.jsp";
                        
                        
                    }
                        
                     }
         
                    
        sc.getRequestDispatcher(url)
                .forward(request, response);
    }
    
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
    
}
