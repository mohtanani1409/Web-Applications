

import java.sql.*;
import java.util.ArrayList;



public class userDB {
    
        public static int createUserTable ()
{
     ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        String query="CREATE TABLE `user` (\n" +
"  `UserID` int(11) NOT NULL,\n" +
"  `Email` varchar(50) DEFAULT NULL,\n" +
"  `FirstName` varchar(50) DEFAULT NULL,\n" +
"  `LastName` varchar(50) DEFAULT NULL,\n" +
"    PRIMARY KEY (UserID)\n" +
"); ";
        try
        {
            ps=connection.prepareStatement(query);
            return ps.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e);
            return 0;
        }
        finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
                

}
   
   
    

    public static int insert(user user) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query
                = "INSERT INTO User (Email, FirstName, LastName) "
                + "VALUES (?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, user.getEmailAddress());
            ps.setString(2, user.getFirstName());
            ps.setString(3, user.getLastName());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static int update(user user) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE User SET "
                + "FirstName = ?, "
                + "LastName = ? "
                + "WHERE Email = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3, user.getEmailAddress());

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static int delete(user user) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "DELETE FROM User "
                + "WHERE Email = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, user.getEmailAddress());

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static boolean emailExists(String email) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT Email FROM User "
                + "WHERE Email = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, email);
            rs = ps.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            System.out.println(e);
            return false;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

    public static user selectUser(int id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM Users "
                + "WHERE userID = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            user user = null;
            if (rs.next()) {
                user = new user();
                user.setId(rs.getString("userName"));
                user.setFirstName(rs.getString("fName"));
                user.setLastName(rs.getString("lName"));
                user.setEmailAddress(rs.getString("email"));
                user.setAddressField1(rs.getString("address"));
                user.setPhoneNumber(rs.getString("phoneNumber"));
            }
            return user;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    
  public static ArrayList<user> selectUsers() {
        
        
                
        ArrayList <user> list=new ArrayList();
        
        // add code that returns an ArrayList<User> object of all users in the User table
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM users ";
        try {
            ps = connection.prepareStatement(query);

            rs = ps.executeQuery();
            
            user us=null;
            
            
            
            while (rs.next()) {
                us=new user();
                
                us.setFirstName(rs.getString("fName"));
                us.setLastName(rs.getString("lName"));
                
                
                us.setId(rs.getString("userName"));
                us.setId2(rs.getString("userID"));
                
                us.setPassword(rs.getString("password"));
                us.setAddressField1(rs.getString("address"));
                us.setEmailAddress(rs.getString("email"));
                us.setRole(rs.getInt("role"));
                us.setPhoneNumber(rs.getString("phoneNumber"));
                
                
                
                us.setRole(rs.getInt("role"));
                
                
                list.add(us);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
        
    }
    
 
         public static int resetPassword(int id,String password) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Users SET "
                + "password = ? "
                + "WHERE userID = ?";
        
        String qq="update users set password=? where userID=?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, password);
            ps.setInt(2, id);
            

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
         
               public static int editProfile(int id,String fName,String lName,String userName,String password,String address,String phoneNumber,String email,String role) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Users SET "
                + "fName = ?, "
                + "lName = ?, "
                + "userName = ?, "
                + "password = ?, "
                + "address = ?, "
                + "phoneNumber = ?, "
                + "email = ?, "
                + "role = ? "
                
                + "WHERE userID = ?";
        
        
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, fName);
            ps.setString(2, lName);
            ps.setString(3, userName);
            ps.setString(4, password);
            ps.setString(5, address);
            ps.setString(6, phoneNumber);
            ps.setString(7, email);
            ps.setString(8, role);
            ps.setInt(9, id);
            
            
            
            

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
               
               public static int editUser(int id,String fName,String lName,String userName,String address,String phoneNumber,String email) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE Users SET "
                + "fName = ?, "
                + "lName = ?, "
                + "userName = ?, "
                + "address = ?, "
                + "phoneNumber = ?, "
                + "email = ? "
                
                
                + "WHERE userID = ?";
        
        
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, fName);
            ps.setString(2, lName);
            ps.setString(3, userName);
            ps.setString(4, address);
            ps.setString(5, phoneNumber);
            ps.setString(6, email);
            ps.setInt(7, id);
            
            
            
            

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
}