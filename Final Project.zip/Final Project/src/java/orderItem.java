
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed
 */
public class orderItem implements Serializable {
    
    public products product;
    int quantity;
    int code;
    int finaltotal=22;
    
    List <Integer> totals=new ArrayList();
    
   public orderItem()
   {
   }
   
   
    public products getProduct() {
        return product;
    }

    public void setProduct(products p) {
        product = p;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    public double getTotal()
    {
        double total=product.getPrice() *quantity;
        
        return total;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }
    
    public double getFinalTotal()
    {
        return finaltotal;
    }
    
    public void setFinalTotl(int cost)
    {
        finaltotal=cost;
    }

    public int getFinaltotal() {
        return finaltotal*quantity;
    }

    public void setFinaltotal(int finaltotal) {
        this.finaltotal = finaltotal;
    }

    public List<Integer> getTotals() {
        return totals;
    }

    public void setTotals(List<Integer> totals) {
        this.totals = totals;
    }
    
    
    
   
}
