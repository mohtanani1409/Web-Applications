/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mohamed
 */
public class adminController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        ServletContext sc = getServletContext();
         
         //productDB db=new productDB ();
         productDB db;
         
          String action=request.getParameter("action");
          
          
          HttpSession session = request.getSession();
          cart cart=(cart) session.getAttribute("cart");
          
        
          
              
          if (action == null) {
            action = "cart";  // default action
        }
        
          
          String url="/mainPage.jsp";
          
          
          //if user clicks on admin button 
          if (action.equals("admin"))
          {
              if (session.getAttribute("role")!=null)
              {
                  
              
              if (session.getAttribute("role").equals(1))
              {
                  
                                              if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
              url="/admin.jsp";    
              
              
            }
              
              else 
              {
                  request.setAttribute("message", "Sign in as an admin first please!");
                  url="/finalMessage.jsp";
              }
              }
              else
              {
                  request.setAttribute("message", "Sign in as an admin first please!");
                  url="/finalMessage.jsp";
                  
              }
              
          }
                        //edit order page 
                        else if (action.equals("editOrders"))
               {
                   
                      session.setAttribute("cart",cart);
              
              
              
              db=new productDB();
              
              
              
              
              ArrayList <order> list22=new ArrayList();
              
              list22=productDB.selectAllOrders();
   
              session.setAttribute("list22", list22);
              
              
                          if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
                   url="/adminOrdersList.jsp";
                   
               }
                        // add item page
                        else if (action.equals("addItem"))
                        {
                                                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                 
                            
                            
                            url="/addItem.jsp";
                            
                        }
          
                // once all text feilds are ready to submit the addition 
               else if (action.equals("addReady"))
                        {
                            
                            String name=request.getParameter("name");
                            String category=request.getParameter("category");
                            String description=request.getParameter("description");
                            String p=request.getParameter("price");
                            int price=Integer.parseInt(p);
                            
                            
                            String image=request.getParameter("image");
                            
                            productDB.addItem(name, category, description, price, image);
                            
                            
                            request.setAttribute("message", "The item has been added successfully.");
            if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                            url="/finalMessage.jsp";
                            
                        }
          
               //once order number
               else if (action.equals("Edit"))
               {
                   String num=request.getParameter("orderNumber");
                   String date=request.getParameter("date");
                   String cost=request.getParameter("totalCost");
                   String userID=request.getParameter("userID");
                   
                   
                   int id=Integer.parseInt(num);
//                   
//                   
//                   
                   float cost2=Float.parseFloat(cost);
                   session.setAttribute("orderId", id);
                   session.setAttribute("date", date);
//                   
                   session.setAttribute("totalCost", cost2);
//                   
                   request.setAttribute("date", date);
                   request.setAttribute("totalCost", cost2);
                   request.setAttribute("userID", userID);
//                   
//                   
             if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                  
                   url="/editOrder.jsp";
               }
               
               // once all text fields are ready to submit the edition 
               else if (action.equals("editOrderReady"))
               {
                   
                   int id=(int) session.getAttribute("orderId");
                   String id2=request.getParameter("userId");
                   String date=request.getParameter("date");
                   
                   int userId=Integer.parseInt(id2);
                   
                   
                   String total=request.getParameter("totalCost");
                   float total2=Float.parseFloat(total);
                   
                   
                    //productDB.editOrder(id, date, userId, tax2, total2);
                    productDB.editOrder(id, date, userId, total2);
                    
                    
                    
                   
                    
         if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                     request.setAttribute("message", "The order has been updated successfully.");
                     
               if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                    
                    url="/finalMessage.jsp";
                            
                   
                   
               }
         
               //delete an order
               else if (action.equals("Delete"))
               {
                   String num=request.getParameter("orderNumber");
                   int id=Integer.parseInt(num);
                   request.setAttribute("date2", num);
                   
                   productDB.deleteItem(id);
                   request.setAttribute("message", "The order has been deleted successfully. ");
                    if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                   url="/finalMessage.jsp";
               }
               //edit user profile
               else if (action.equals("editUsers"))
               {
                   List <user>list=new ArrayList<>();
                    list=userDB.selectUsers();
                    request.setAttribute("users", list);
                    
                     if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                    url="/usersList.jsp";
               }
               
               //edit user page
               else if (action.equals("editUser"))
               {
                   user us=new user();
                   String id=request.getParameter("userID");
                   int id2=Integer.parseInt(id);
                  us= userDB.selectUser(id2);
                  request.setAttribute("setID", id2);
                  request.setAttribute("fName", us.firstName);
                  request.setAttribute("lName", us.lastName);
                  request.setAttribute("userName", us.id);
                  request.setAttribute("email", us.emailAddress);
                  request.setAttribute("address", us.addressField1);
                  request.setAttribute("phoneNumber", us.phoneNumber);
                  
                    if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                  
                                    
                  url="/editUser.jsp";
               }
          
               //submit eddition
               else if (action.equals("editUserReady"))
               {
                   String id=request.getParameter("setID");
                   int id2=Integer.parseInt(id);
                   String fName=request.getParameter("fName");
                   String lName=request.getParameter("lName");
                   String userName=request.getParameter("userName");
                   String email=request.getParameter("email");
                   String address=request.getParameter("address");
                   String number=request.getParameter("phoneNumber");
                   
                   userDB.editUser(id2, fName, lName, userName, address, number, email);
                   request.setAttribute("message", "The user has been eddited successfully");
          if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                   url="/finalMessage.jsp";
               }
               
               //update products
               else if (action.equals("updateInventpry"))
               {
                   
                   List <products>products=new ArrayList<>();
                   products=productDB.selectProducts();
                   request.setAttribute("products", products);
    if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                    
                   url="/adminProductsList.jsp";
               }
          
               //delete product
               else if (action.equals("deleteProduct"))
               {
                   String id=request.getParameter("id");
                   int id2=Integer.parseInt(id);
                   
                   productDB.deleteProduct(id2);
                   
                   request.setAttribute("message", "Item has been deleted successfully.");
                       if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                   url="/finalMessage.jsp";
               }
          
               //update product page
               else if (action.equals("updateProduct"))
               {
                   String id=request.getParameter("id");
                   session.setAttribute("productEditID", id);
                   products pr=new products();
                   pr=productDB.selectproduct(id);
                   request.setAttribute("name2", pr.name);
                   request.setAttribute("category", pr.category);
                   request.setAttribute("description", pr.description);
                   request.setAttribute("price", pr.price);
                   request.setAttribute("image", pr.imageURL);
                       if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
                   url="/adminEditProduct.jsp";
               }
          
               //submit product edditing
               else if (action.equals("editProductReady"))
               {
                   String id=(String) session.getAttribute("productEditID");
                   
                   int id2=Integer.parseInt(id);
                   String name=request.getParameter("name");
                   String category=request.getParameter("category");
                   String description=request.getParameter("description");
                   String price=request.getParameter("price");
                   int pr=Integer.parseInt(price);
                   String image=request.getParameter("image");
                   
                   productDB.editProduct(id2, name, category, description, pr, image);
                   
                   
               }
                 
          
        sc.getRequestDispatcher(url)
                .forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
