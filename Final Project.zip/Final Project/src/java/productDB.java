import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Mohamed
 */


public class productDB  extends HttpServlet {
    
    
        //add product
        public static int addProduct(products product) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        //HttpSession session = request.getSession();
        //cart cart=(cart) session.getAttribute("cart");

        String query
                = "INSERT INTO User (ProductCode, Name, CatelogCategory,description,price,ImageURL) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, product.getCode() );
            ps.setString(2, product.getName());
            ps.setString(3, product.getCategory());
            ps.setString(4, product.getDescription());
            ps.setInt(5, product.getPrice());
            ps.setString(6, product.getImageURL());
            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }

        //create product table
    public static int createProductTable ()
{
     ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        
        String query="CREATE TABLE `product` (\n" +
"  `ProductCode` int(11) NOT NULL DEFAULT '0',\n" +
"  `Name` varchar(50) DEFAULT NULL,\n" +
"  `CatelogCategory` varchar(50) DEFAULT NULL,\n" +
"  `Description` varchar(255) DEFAULT NULL,\n" +
"  `Price` int(11) DEFAULT NULL,\n" +
"  `ImageURL` varchar(12000) DEFAULT NULL,\n" +
"   PRIMARY KEY (ProductCode) \n" +
");";
        try
        {
            ps=connection.prepareStatement(query);
            return ps.executeUpdate();
        }
        catch (SQLException e)
        {
            System.out.println(e);
            return 0;
        }
        finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
                

}
   
      public static int selectPrice(String id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT price FROM product "
                + "WHERE ProductCode = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            int price=0;
            products product=null;
            if (rs.next()) {
    
                price=rs.getInt("Price");
              
                
                
            }
            return price;
        } catch (SQLException e) {
            System.out.println(e);
            return 2;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
    public static products selectproduct(String id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM product "
                + "WHERE ProductCode = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            products product=null;
            if (rs.next()) {
                product = new products();
                product.setCode(rs.getInt("productCode"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getInt("Price"));
                product.setDescription(rs.getString("Description"));
                product.setCategory(rs.getString("CatelogCategory"));
                product.setImageURL(rs.getString("ImageURL"));
                
                
            }
            return product;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }


    
    public static ArrayList<products> selectProducts() {
        
        
                
        ArrayList <products> list=new ArrayList();
        
        // add code that returns an ArrayList<User> object of all users in the User table
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM product ";
        try {
            ps = connection.prepareStatement(query);

            rs = ps.executeQuery();
            //user user = null;
            products product=null;
            
            
            while (rs.next()) {
                product = new products();
                product.setCode(rs.getInt("productCode"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getInt("Price"));
                product.setDescription(rs.getString("Description"));
                product.setCategory(rs.getString("CatelogCategory"));
                product.setImageURL(rs.getString("ImageURL"));
                


                list.add(product);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
        
    }
    
        public static ArrayList<order> selectOrders(int userID) {
        
        
                
        ArrayList <order> list=new ArrayList();
        
        // add code that returns an ArrayList<User> object of all users in the User table
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM orders where userID=? ";
        try {
            ps = connection.prepareStatement(query);
            
            ps.setInt(1, userID);

            rs = ps.executeQuery();
            
            order or=null;
            
            
            while (rs.next()) {
                or=new order();
                
                or.setOrderNumber(rs.getInt("orderNumber"));
                or.setDate(rs.getString("date"));
                
                
                or.setUser(rs.getInt("userID"));
                
                or.setTaxRate(rs.getFloat("taxrate"));
                or.setTotalCost(rs.getFloat("totalCost"));
                or.setFlag(rs.getInt("paid"));
                


                list.add(or);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
        
    }
             public static ArrayList<order> selectAllOrders() {
        
        
                
        ArrayList <order> list=new ArrayList();
        
        // add code that returns an ArrayList<User> object of all users in the User table
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM orders ";
        try {
            ps = connection.prepareStatement(query);

            rs = ps.executeQuery();
            
            order or=null;
            
            
            while (rs.next()) {
                or=new order();
                
                or.setOrderNumber(rs.getInt("orderNumber"));
                or.setDate(rs.getString("date"));
                
                
                or.setUser(rs.getInt("userID"));
                
                or.setTaxRate(rs.getFloat("taxrate"));
                or.setTotalCost(rs.getFloat("totalCost"));
                or.setFlag(rs.getInt("paid"));
                


                list.add(or);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
        
    }


public static void addOrderItem(cart cc)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
        String query="insert into orderItem ( productCode, quantity) "+"values (?,?)";
        

        try
        {
            
        int tot=cc.items.get(0).getFinaltotal();
        
        
        ps = connection.prepareStatement(query);
        
        for (int x=0;x<cc.items.size();x++)
        {
            
        
           // ps.setInt(1, x );
                ps.setInt(1,cc.items.get(x).code);

            ps.setInt(2,cc.items.get(x).quantity );
            ps.executeUpdate();
        }

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
   
}



public static void addOrder(cart cc, String userID)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        
          DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
                Date date = new Date();
                
                String date2=dateFormat.format(date);
                
                int user=Integer.parseInt(userID);
        
        float totalCost=0;
           for (int x=0;x<cc.items.size();x++)
        {
            totalCost+=cc.items.get(x).getFinaltotal();
        }
           
           
           
        float tax=(float) (totalCost*0.09);

       
        
        String query="insert into orders (date,userID,taxRate,totalCost,paid) "+"values (?,?,?,?,?)";
        

        try
        {
                    
        
        ps = connection.prepareStatement(query);
        
     
                ps.setString(1, date2);
                ps.setInt(2, user);
                ps.setFloat(3,tax);
                ps.setFloat(4, totalCost+tax);
                ps.setInt(5,1);
         
            ps.executeUpdate();
        

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
       
       
   
}
    

public static void addUser(String fname,String lname,String uname,String password,String email, String address,String phoneNumber,String role)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
   
        
        String query="insert into users (fName,lName,userName,password,email,address,phoneNumber,role) "+"values (?,?,?,?,?,?,?,?)";
        

        try
        {
                    
        
        ps = connection.prepareStatement(query);
        
     
                
                ps.setString(1,fname );
                ps.setString(2,lname);
                ps.setString(3, uname);
                ps.setString(4,password);
                ps.setString(5,email);
                ps.setString(6,address);
                ps.setString(7,phoneNumber);
                ps.setString(8,role);
         
            ps.executeUpdate();
        

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
       
       
   
}

  public static ArrayList<user> selectUsers() {
        
        
                
        ArrayList <user> list=new ArrayList();
        
        // add code that returns an ArrayList<User> object of all users in the User table
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;

        String query = "SELECT * FROM users ";
        try {
            ps = connection.prepareStatement(query);

            rs = ps.executeQuery();
            
            user us=null;
            
            
            
            while (rs.next()) {
                us=new user();
                
                us.setFirstName(rs.getString("fName"));
                us.setLastName(rs.getString("lName"));
                
                
                us.setId(rs.getString("userName"));
                us.setId2(rs.getString("userID"));
                
                us.setPassword(rs.getString("password"));
                us.setAddressField1(rs.getString("address"));
                us.setEmailAddress(rs.getString("email"));
                us.setRole(rs.getInt("role"));
                us.setPhoneNumber(rs.getString("phoneNumber"));
                
                
                
                us.setRole(rs.getInt("role"));
                
                
                list.add(us);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            return null;
        } finally {
            DBUtil.closeResultSet(rs);
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
        
        
    }
  
  public static void addItem(String name,String category,String description,int price,String image)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
   
        
        String query="insert into product (Name,catelogCategory,description,price,imageURL) "+"values (?,?,?,?,?)";
        

        try
        {
                    
        
        ps = connection.prepareStatement(query);
        
     
                
                ps.setString(1,name );
                ps.setString(2,category);
                ps.setString(3, description);
                ps.setInt(4,price);
                ps.setString(5,image);
                         
            ps.executeUpdate();
        

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
       
       
   
}
  
    public static void deleteItem(int id)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
   
        
        //String query="Delete from orders (where orderNumber=48) "+"values (?)";
        String query="Delete from orders where orderNumber=?";
        

        try
        {
                    
        
        ps = connection.prepareStatement(query);
        
     
                
                ps.setInt(1,id );
             
                         
            ps.executeUpdate();
        

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
       
       
   
}
    
            public static int editOrder(int id,String date,int userID, float totalCost) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE orders SET "
                + "date = ?, "
                + "userID = ?, "
                
                + "totalCost = ? "
                
                + "WHERE orderNumber = ?";
        
        
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, date);
            ps.setInt(2, userID);
            
            ps.setFloat(3, totalCost);
            ps.setInt(4, id);
         
            
            
            
            

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
            
    public static void deleteProduct(int id)
{
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
   
        
        
        String query="Delete from product where ProductCode=?";
        

        try
        {
                    
        
        ps = connection.prepareStatement(query);
        
     
                
                ps.setInt(1,id );
             
                         
            ps.executeUpdate();
        

        }
        
        catch (SQLException e) {
            System.out.println(e);
            //return 0;
        }
        
       // }
       
       
   
}
    
            public static int editProduct(int id,String name,String cat, String des, int price, String image) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;

        String query = "UPDATE product SET "
                + "name = ?, "
                + "catelogCategory = ?, "
                
                + "description = ?, "
                + "price = ?, "
                + "imageURL = ? "
                
                + "WHERE productCode = ?";
        
        
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, cat);
            
            ps.setString(3, des);
            ps.setInt(4, price);
            ps.setString(5, image);
            ps.setInt(6, id);
         
            
            
            
            

            return ps.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
            return 0;
        } finally {
            DBUtil.closePreparedStatement(ps);
            pool.freeConnection(connection);
        }
    }
   


    
    
}