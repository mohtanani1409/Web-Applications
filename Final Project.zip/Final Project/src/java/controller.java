/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Image;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import static javax.servlet.SessionTrackingMode.URL;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Mohamed
 */
public class controller extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        
        productDB db=new productDB ();
        cart car=new cart();
         
        Image image=null;
        HttpSession session = request.getSession();
      
         
        
        String url="";
        
        String action=request.getParameter("action");
        
        if (action==null)
            action="home";
        
        //home page
        if (action.equals("home"))
        {
            
                  if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            
            url="/mainPage.jsp";
            
            
        }
        
        //catalog page
        else if (action.equals("catalog"))
        {
           
            ArrayList <products> product=productDB.selectProducts();

            request.setAttribute("products", product);
            
            
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/catalog.jsp";
            
            
        }
         
        //about page
        else if (action.equals("about"))
        {
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            
            url="/about.jsp";
            
          
        }
        
        //contact us page
        else if (action.equals("contact"))
        {
                     if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/contactUS.jsp";
            
            
        }
               
        //going back to catalog from details page
        else if (action.equals("back"))
        {
             
            ArrayList <products> product=productDB.selectProducts();
    
            request.setAttribute("products", product);
           
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/catalog.jsp";
            
            
        }
        
        //order page
        else if (action.equals("order"))
        {
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/order.jsp";
            
            
        }
        
        //cehckout page
        else if (action.equals("checkout"))
        {            if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/order.jsp";
            
            
        }
 

       //item details page
        else 
        {
            List <products> productsList=new ArrayList<>();
             productsList=productDB.selectProducts();
   
                      products product=productDB.selectproduct(request.getParameter("id2"));
            request.setAttribute("product", product);
   
                        if (session.getAttribute("userName")==null)
          {
              request.setAttribute("name","Not Signed In ");
          }
                  else 
                  {
                       request.setAttribute("name","Signed In: "+ session.getAttribute("userName"));
                  }
            
            url="/itemDetails.jsp";
            
            
        }
        
        
                 getServletContext().getRequestDispatcher(url).forward(request, response);           
        
       
         
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
